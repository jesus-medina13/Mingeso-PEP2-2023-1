package proveedorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProveedorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
