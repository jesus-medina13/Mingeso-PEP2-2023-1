package planillaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlanillaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlanillaServiceApplication.class, args);
	}

}
